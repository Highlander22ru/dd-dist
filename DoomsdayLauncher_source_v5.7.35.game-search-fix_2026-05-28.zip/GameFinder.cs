using System.IO;
using Microsoft.Win32;

namespace DoomsdayLauncher;

public static class GameFinder
{
    private static readonly string[] GameDirNames = { "7 Days To Die", "7DaysToDie", "7DTD" };

    /// <summary>Find ALL valid game installations on the system.</summary>
    public static List<string> FindAllGameInstalls()
    {
        var found = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // 1) Steam libraries (primary)
        foreach (var steam in GetSteamInstallPaths())
        {
            try
            {
                AddIfValid(found, Path.Combine(steam, "steamapps", "common", "7 Days To Die"));

                var vdf = Path.Combine(steam, "steamapps", "libraryfolders.vdf");
                if (File.Exists(vdf))
                {
                    var content = File.ReadAllText(vdf);
                    foreach (var libPath in ParseSteamLibraryFolders(content))
                    {
                        AddIfValid(found, Path.Combine(libPath, "steamapps", "common", "7 Days To Die"));
                        AddIfValidFromAppManifest(found, libPath);
                    }
                }

                AddIfValidFromAppManifest(found, steam);
            }
            catch { }
        }

        // 2) Well-known root patterns on each fixed drive
        foreach (var drive in DriveInfo.GetDrives())
        {
            if (drive.DriveType != DriveType.Fixed) continue;
            var root = drive.RootDirectory.FullName;
            foreach (var n in GameDirNames)
            {
                AddIfValid(found, Path.Combine(root, n));
                AddIfValid(found, Path.Combine(root, n, n));
                AddIfValid(found, Path.Combine(root, "Games", n));
                AddIfValid(found, Path.Combine(root, "Games", n, n));
                AddIfValid(found, Path.Combine(root, "SteamLibrary", "steamapps", "common", n));
                AddIfValid(found, Path.Combine(root, "Program Files", "Steam", "steamapps", "common", n));
                AddIfValid(found, Path.Combine(root, "Program Files (x86)", "Steam", "steamapps", "common", n));
            }
        }

        return found.ToList();
    }

    private static IEnumerable<string> GetSteamInstallPaths()
    {
        var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var hive in new[] { RegistryHive.LocalMachine, RegistryHive.CurrentUser })
        foreach (var view in new[] { RegistryView.Registry64, RegistryView.Registry32 })
        {
            try
            {
                using var root = RegistryKey.OpenBaseKey(hive, view);
                using var key = root.OpenSubKey(@"SOFTWARE\Valve\Steam")
                    ?? root.OpenSubKey(@"SOFTWARE\WOW6432Node\Valve\Steam");
                if (key?.GetValue("InstallPath") is string path && !string.IsNullOrWhiteSpace(path))
                    paths.Add(path);
                if (key?.GetValue("SteamPath") is string steamPath && !string.IsNullOrWhiteSpace(steamPath))
                    paths.Add(steamPath.Replace('/', Path.DirectorySeparatorChar));
            }
            catch { }
        }
        return paths;
    }

    private static IEnumerable<string> ParseSteamLibraryFolders(string content)
    {
        var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (System.Text.RegularExpressions.Match m in
            System.Text.RegularExpressions.Regex.Matches(content, "\"path\"\\s*\"([^\"]+)\""))
            paths.Add(m.Groups[1].Value.Replace("\\\\", "\\"));

        foreach (System.Text.RegularExpressions.Match m in
            System.Text.RegularExpressions.Regex.Matches(content, "\"\\d+\"\\s*\"([A-Za-z]:[^\\\"]+)\""))
            paths.Add(m.Groups[1].Value.Replace("\\\\", "\\"));

        return paths;
    }

    private static void AddIfValidFromAppManifest(HashSet<string> set, string steamLibraryPath)
    {
        try
        {
            var manifest = Path.Combine(steamLibraryPath, "steamapps", "appmanifest_251570.acf");
            if (!File.Exists(manifest)) return;

            var content = File.ReadAllText(manifest);
            var match = System.Text.RegularExpressions.Regex.Match(content, "\"installdir\"\\s*\"([^\"]+)\"");
            var installDir = match.Success ? match.Groups[1].Value : "7 Days To Die";
            AddIfValid(set, Path.Combine(steamLibraryPath, "steamapps", "common", installDir));
        }
        catch { }
    }

    private static void AddIfValid(HashSet<string> set, string path)
    {
        try
        {
            if (File.Exists(Path.Combine(path, "7DaysToDie.exe")))
                set.Add(Path.GetFullPath(path));
        }
        catch { }
    }

    public static string? FindGamePath() => FindAllGameInstalls().FirstOrDefault();

    public static string GetModsPath(string gamePath) =>
        Path.Combine(gamePath, "Mods");

    public static string GetDoomsdayClientDllPath(string gamePath) =>
        Path.Combine(gamePath, "Mods", "DoomsdayClient", "DoomsdayClient.dll");

    public static string GetDoomsdayClientModInfoPath(string gamePath) =>
        Path.Combine(gamePath, "Mods", "DoomsdayClient", "ModInfo.xml");

    public static string GetMenuMusicReplacerDirPath(string gamePath) =>
        Path.Combine(gamePath, "Mods", "MenuMusicReplacer");

    public static string GetMenuMusicReplacerDllPath(string gamePath) =>
        Path.Combine(gamePath, "Mods", "MenuMusicReplacer", "MenuMusicReplacer.dll");

    public static string GetMenuMusicReplacerOggPath(string gamePath) =>
        Path.Combine(gamePath, "Mods", "MenuMusicReplacer", "music", "horde_theme.ogg");

    public static string GetMenuMusicReplacerModInfoPath(string gamePath) =>
        Path.Combine(gamePath, "Mods", "MenuMusicReplacer", "ModInfo.xml");

    public static string GetGameExePath(string gamePath) =>
        Path.Combine(gamePath, "7DaysToDie.exe");

    public static readonly HashSet<string> AllowedMods = new(StringComparer.OrdinalIgnoreCase)
    {
        "0_TFP_Harmony",
        "DoomsdayClient",
        "MenuMusicReplacer",
    };

    // Dev-environment markers — if any of these exist in Mods/, refuse automatic cleanup
    public static readonly HashSet<string> DevMarkers = new(StringComparer.OrdinalIgnoreCase)
    {
        ".git", ".github", ".vscode", ".venv", ".idea", ".claude", ".playwright-mcp",
        "node_modules", "obj", "bin"
    };

    public record CleanPlan(List<string> Folders, List<string> Files, bool IsDevWorkspace);

    public static CleanPlan PreviewCleanup(string gamePath)
    {
        var folders = new List<string>();
        var files = new List<string>();
        bool dev = false;
        var modsPath = GetModsPath(gamePath);
        if (!Directory.Exists(modsPath)) return new CleanPlan(folders, files, false);

        foreach (var sub in Directory.GetDirectories(modsPath))
        {
            var name = Path.GetFileName(sub);
            if (AllowedMods.Contains(name)) continue;
            if (DevMarkers.Contains(name) || ContainsDevMarker(sub)) { dev = true; continue; }
            folders.Add(name);
        }
        // Any dev marker anywhere in Mods root?
        foreach (var sub in Directory.GetDirectories(modsPath))
            if (DevMarkers.Contains(Path.GetFileName(sub))) dev = true;

        foreach (var file in Directory.GetFiles(modsPath))
            files.Add(Path.GetFileName(file));

        return new CleanPlan(folders, files, dev);
    }

    public static bool RemoveLegacyDoomsdayXmlMod(string gamePath, out string? message)
    {
        message = null;
        var legacyDir = Path.Combine(GetModsPath(gamePath), "Doomsday");
        if (!Directory.Exists(legacyDir)) return false;

        if (ContainsDevMarker(legacyDir))
        {
            message = "Найдена папка Mods\\Doomsday, но она похожа на DEV-папку; автоудаление пропущено";
            return false;
        }

        message = "Mods\\Doomsday удаляется только через общее подтверждение очистки Mods";
        return false;
    }

    private static bool ContainsDevMarker(string dir)
    {
        try
        {
            foreach (var entry in Directory.EnumerateFileSystemEntries(dir, "*", SearchOption.AllDirectories))
            {
                if (DevMarkers.Contains(Path.GetFileName(entry))) return true;
            }
        }
        catch { }
        return false;
    }

    /// <summary>
    /// Rename EasyAntiCheat folder so the game cannot load EAC launcher.
    /// Returns true if EAC was physically disabled now (or already disabled).
    /// </summary>
    public static bool DisableEasyAntiCheat(string gamePath, out string message)
    {
        var eacActive = Path.Combine(gamePath, "EasyAntiCheat");
        var eacDisabled = Path.Combine(gamePath, "EasyAntiCheat_disabled");

        if (Directory.Exists(eacDisabled) && !Directory.Exists(eacActive))
        {
            message = "EAC уже отключён (папка переименована в EasyAntiCheat_disabled)";
            return true;
        }

        if (!Directory.Exists(eacActive))
        {
            message = "Папка EasyAntiCheat не найдена — возможно, игра уже без EAC";
            return true;
        }

        try
        {
            if (Directory.Exists(eacDisabled))
            {
                // Merge: delete old disabled and rename active
                Directory.Delete(eacDisabled, recursive: true);
            }
            Directory.Move(eacActive, eacDisabled);
            message = "EAC отключён (папка переименована в EasyAntiCheat_disabled)";
            return true;
        }
        catch (Exception ex)
        {
            message = "Не удалось переименовать папку EAC: " + ex.Message;
            return false;
        }
    }

    public static bool IsEacDisabled(string gamePath)
    {
        return !Directory.Exists(Path.Combine(gamePath, "EasyAntiCheat"))
            || Directory.Exists(Path.Combine(gamePath, "EasyAntiCheat_disabled"));
    }

    public static List<string> CleanMods(string gamePath)
    {
        var removed = new List<string>();
        var failures = new List<string>();
        var modsPath = GetModsPath(gamePath);
        if (!Directory.Exists(modsPath)) return removed;

        foreach (var sub in Directory.GetDirectories(modsPath))
        {
            var name = Path.GetFileName(sub);
            if (AllowedMods.Contains(name)) continue;
            if (DevMarkers.Contains(name) || ContainsDevMarker(sub)) continue; // Protect dev folders
            try { Directory.Delete(sub, true); removed.Add(name); }
            catch (Exception ex) { failures.Add(name + ": " + ex.Message); }
        }
        foreach (var file in Directory.GetFiles(modsPath))
        {
            var name = Path.GetFileName(file);
            try { File.Delete(file); removed.Add("(file) " + name); }
            catch (Exception ex) { failures.Add("(file) " + name + ": " + ex.Message); }
        }
        if (failures.Count > 0)
            throw new IOException("Не удалось удалить из Mods: " + string.Join("; ", failures));
        return removed;
    }
}
