using System.Net.Http;

namespace DoomsdayLauncher;

/// <summary>Downloader for canonical VPS-hosted release artifacts.</summary>
public static class Sources
{
    // Production source of truth is the VPS /dl path. GitHub Release is the first fallback.
    private const string RawMirrorRef = "raw-v5.7";

    private static readonly string[] ArtifactMirrors = new[]
    {
        "https://doomsday7dtd.online/dl",
        "https://doomsday7dtd.ru/dl",
        "https://github.com/Highlander22ru/dd-dist/releases/download/v5.7",
        "https://raw.githubusercontent.com/Highlander22ru/dd-dist/" + RawMirrorRef,
        "https://cdn.jsdelivr.net/gh/Highlander22ru/dd-dist@" + RawMirrorRef,
    };

    private static readonly string[] LauncherManifestMirrors = new[]
    {
        "https://doomsday7dtd.online/dl",
        "https://doomsday7dtd.ru/dl",
        "https://github.com/Highlander22ru/dd-dist/releases/download/v5.7",
        "https://raw.githubusercontent.com/Highlander22ru/dd-dist/" + RawMirrorRef,
        "https://cdn.jsdelivr.net/gh/Highlander22ru/dd-dist@" + RawMirrorRef,
    };

    /// <summary>Max wait per mirror before trying the next one (seconds).
    /// v5.1: 3 → 15 сек. 3 секунд не хватало на TLS handshake через CloudFlare в плохих
    /// каналах (РФ/Беларусь): соединение устанавливалось дольше → CancellationToken отменял
    /// до получения первого байта → переход на следующий mirror → каскадные таймауты.</summary>
    public const int PerAttemptTimeoutSeconds = 90;

    public const string LauncherJsonName = "launcher.json";
    public const string ClientJsonName = "client.json";
    public const string ModInfoName = "ModInfo.xml";
    public const string DllName = "DoomsdayClient.dll";
    public const string LauncherExeName = "DoomsdayLauncher.exe";

    // MenuMusicReplacer mod (cosmetic, client-side)
    public const string MenuMusicJsonName = "menumusic.json";
    public const string MenuMusicDllName = "MenuMusicReplacer.dll";
    public const string MenuMusicOggName = "horde_theme.ogg";
    public const string MenuMusicModInfoName = "MenuMusicReplacer_ModInfo.xml";

    /// <summary>Expand a file name into full URLs per mirror, with a primary override first (e.g. from JSON).</summary>
    public static IEnumerable<string> UrlsFor(string fileName, string? primaryOverride = null)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (!string.IsNullOrEmpty(primaryOverride) && IsAllowedDownloadUrl(primaryOverride))
        {
            yield return primaryOverride;
            seen.Add(primaryOverride);
        }
        foreach (var m in MirrorsFor(fileName))
        {
            var url = m.TrimEnd('/') + "/" + fileName;
            if (seen.Add(url)) yield return url;
        }
    }

    private static IEnumerable<string> MirrorsFor(string fileName) =>
        string.Equals(fileName, LauncherJsonName, StringComparison.OrdinalIgnoreCase)
            ? LauncherManifestMirrors
            : ArtifactMirrors;

    private static bool IsAllowedDownloadUrl(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri)) return false;
        if (!string.Equals(uri.Scheme, Uri.UriSchemeHttps, StringComparison.OrdinalIgnoreCase)) return false;

        if (string.Equals(uri.Host, "doomsday7dtd.online", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(uri.Host, "doomsday7dtd.ru", StringComparison.OrdinalIgnoreCase))
            return uri.AbsolutePath.StartsWith("/dl/", StringComparison.Ordinal);

        if (string.Equals(uri.Host, "github.com", StringComparison.OrdinalIgnoreCase))
            return uri.AbsolutePath.StartsWith("/Highlander22ru/dd-dist/releases/download/v5.7/", StringComparison.Ordinal);

        if (string.Equals(uri.Host, "raw.githubusercontent.com", StringComparison.OrdinalIgnoreCase))
            return uri.AbsolutePath.StartsWith("/Highlander22ru/dd-dist/" + RawMirrorRef + "/", StringComparison.Ordinal);

        if (string.Equals(uri.Host, "cdn.jsdelivr.net", StringComparison.OrdinalIgnoreCase))
            return uri.AbsolutePath.StartsWith("/gh/Highlander22ru/dd-dist@" + RawMirrorRef + "/", StringComparison.Ordinal);

        return false;
    }

    /// <summary>GET from allowed release source. Reports the attempt via onAttempt.
    /// The request gets <see cref="PerAttemptTimeoutSeconds"/> to start responding.</summary>
    public static async Task<HttpResponseMessage> GetWithFallbackAsync(
        HttpClient http,
        string fileName,
        string? primaryOverride = null,
        Action<string, string>? onAttempt = null,
        CancellationToken ct = default)
    {
        Exception? last = null;
        foreach (var url in UrlsFor(fileName, primaryOverride))
        {
            onAttempt?.Invoke(url, "пробую...");
            using var perAttempt = CancellationTokenSource.CreateLinkedTokenSource(ct);
            perAttempt.CancelAfter(TimeSpan.FromSeconds(PerAttemptTimeoutSeconds));
            try
            {
                var resp = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, perAttempt.Token);
                if (resp.IsSuccessStatusCode)
                {
                    onAttempt?.Invoke(url, "OK");
                    return resp;
                }
                last = new HttpRequestException($"{url}: HTTP {(int)resp.StatusCode}");
                onAttempt?.Invoke(url, $"HTTP {(int)resp.StatusCode}");
                resp.Dispose();
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                last = new TimeoutException($"{url}: нет ответа за {PerAttemptTimeoutSeconds}с");
                onAttempt?.Invoke(url, $"таймаут {PerAttemptTimeoutSeconds}с");
            }
            catch (Exception ex)
            {
                last = ex;
                onAttempt?.Invoke(url, "ошибка: " + ShortError(ex.Message));
            }
        }
        throw new Exception("Все источники недоступны. Последняя ошибка: " + (last?.Message ?? "неизвестно"));
    }

    /// <summary>Convenience: download full text (JSON/XML).</summary>
    public static async Task<string> GetStringWithFallbackAsync(
        HttpClient http, string fileName, string? primaryOverride = null,
        Action<string, string>? onAttempt = null, CancellationToken ct = default)
    {
        using var resp = await GetWithFallbackAsync(http, fileName, primaryOverride, onAttempt, ct);
        return await resp.Content.ReadAsStringAsync(ct);
    }

    private static string ShortError(string msg) =>
        msg.Length > 80 ? msg[..80] + "..." : msg;
}
