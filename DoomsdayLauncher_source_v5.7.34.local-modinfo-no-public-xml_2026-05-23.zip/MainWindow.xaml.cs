using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace DoomsdayLauncher;

public partial class MainWindow : Window
{
    private static readonly string[] ServersApiUrls =
    {
        "https://doomsday7dtd.online/api/servers/status",
        "https://doomsday7dtd.ru/api/servers/status",
    };
    private const string DISCORD_URL = "https://discord.gg/3u3GwShEhR";
    private static readonly string CURRENT_VERSION = GetCurrentLauncherVersion();

    private readonly HttpClient _http;
    private readonly Config _config;
    private string? _gamePath;
    private ClientInfo? _clientInfo;
    private MenuMusicInfo? _menuMusicInfo;
    private readonly DispatcherTimer _serverTimer;

    public MainWindow()
    {
        InitializeComponent();

        _http = new HttpClient { Timeout = TimeSpan.FromMinutes(15) };
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("DoomsdayLauncher/" + CURRENT_VERSION);

        _config = Config.Load();
        txtLauncherVer.Text = "v" + CURRENT_VERSION;

        _serverTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(15) };
        _serverTimer.Tick += async (_, _) => await RefreshServersAsync();

        Loaded += async (_, _) =>
        {
            await InitializeAsync();
            _ = RefreshServersAsync();
            _serverTimer.Start();
        };

        Closed += (_, _) => _serverTimer.Stop();
    }

    private static string GetCurrentLauncherVersion()
    {
        var version = typeof(MainWindow).Assembly.GetName().Version;
        if (version == null) return "0.0.0";
        return $"{version.Major}.{version.Minor}.{version.Build}";
    }

    private async Task InitializeAsync()
    {
        if (EnsureLauncherInstalledAndRestart())
            return;

        SetStatus("Ищу 7 Days To Die...");

        // Prefer saved path if still valid. This lets the EAC status update immediately
        // instead of waiting for drive/Steam-library discovery.
        if (!string.IsNullOrWhiteSpace(_config.GamePath) && File.Exists(GameFinder.GetGameExePath(_config.GamePath)))
            _gamePath = _config.GamePath;
        else
        {
            var installs = await Task.Run(GameFinder.FindAllGameInstalls);
            if (installs.Count > 0)
                _gamePath = installs[0];
        }

        if (_gamePath == null)
        {
            SetStatus("❌ Игра не найдена. Нажми «ВЫБРАТЬ ПАПКУ».", error: true);
            txtPath.Text = "(не найдено)";
            return;
        }

        txtPath.Text = _gamePath;
        _config.GamePath = _gamePath;
        _config.Save();
        UpdateEacStatus();

        // v5.2: Enable copy button сразу как игра найдена, НЕ ждём download.
        // Это позволяет игроку скопировать игру в другую папку даже если client.dll не качается.
        btnCopyElsewhere.IsEnabled = true;

        await ProceedAsync();
    }

    private async Task ProceedAsync()
    {
        try
        {
            if (await CheckLauncherUpdateAsync())
                return;

            // DLL + ModInfo
            var clientJson = await Sources.GetStringWithFallbackAsync(_http, Sources.ClientJsonName);
            _clientInfo = JsonSerializer.Deserialize<ClientInfo>(clientJson);
            if (_clientInfo != null)
            {
                txtDllVer.Text = "v" + _clientInfo.Version;
                await EnsureModUpToDate(_clientInfo);
                EnsureTfpHarmonyModInfo();
            }

            // MenuMusicReplacer mod (cosmetic, optional — silent failure if menumusic.json missing)
            try
            {
                var mmJson = await Sources.GetStringWithFallbackAsync(_http, Sources.MenuMusicJsonName);
                _menuMusicInfo = JsonSerializer.Deserialize<MenuMusicInfo>(mmJson);
                if (_menuMusicInfo != null)
                {
                    await EnsureMenuMusicUpToDate(_menuMusicInfo);
                }
            }
            catch (Exception ex)
            {
                // not fatal — menu music is cosmetic
                System.Diagnostics.Debug.WriteLine("MenuMusicReplacer fetch failed: " + ex.Message);
            }

            // Warn in status if foreign mods will be wiped on launch
            var plan = GameFinder.PreviewCleanup(_gamePath!);
            if (plan.Folders.Count > 0 || plan.Files.Count > 0)
            {
                var total = plan.Folders.Count + plan.Files.Count;
                SetStatus($"⚠ В Mods обнаружено {total} чужих папок/файлов — они будут удалены при запуске. Жми ИГРАТЬ.");
            }
            else
            {
                SetStatus("✓ Всё готово — жми ИГРАТЬ");
            }
            btnPlay.IsEnabled = true;
            // btnCopyElsewhere уже включён ранее (после gamePath found)
        }
        catch (Exception ex)
        {
            SetStatus("❌ " + ex.Message, error: true);
            // v5.2: btnCopyElsewhere остаётся активной — игрок может обойти проблему копированием
        }
    }

    private async Task<bool> CheckLauncherUpdateAsync()
    {
        try
        {
            var launcherJson = await Sources.GetStringWithFallbackAsync(_http, Sources.LauncherJsonName);
            var info = JsonSerializer.Deserialize<LauncherInfo>(launcherJson);
            if (info == null || !IsRemoteNewer(info.Version, CURRENT_VERSION))
                return false;

            var ask = MessageBox.Show(
                $"Доступна новая версия лаунчера v{info.Version}.\n\n" +
                $"Текущая версия: v{CURRENT_VERSION}\n" +
                $"Размер: {FormatSize(info.Size)}\n\n" +
                "Скачать с официального VPS, проверить SHA256 и запустить новую версию?",
                "Обновление лаунчера",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (ask != MessageBoxResult.Yes)
            {
                SetStatus($"Доступна новая версия лаунчера v{info.Version}: doomsday7dtd.online/launcher.html / doomsday7dtd.ru/launcher.html");
                return false;
            }

            var updatePath = GetLauncherUpdatePath(info);
            if (!IsVerifiedFile(updatePath, info.Size, info.Sha256))
            {
                SetStatus($"Скачиваю лаунчер v{info.Version}...");
                await DownloadWithFallbackAndProgress(Path.GetFileName(updatePath), updatePath, info.Size, info.Url);
            }

            if (!IsVerifiedFile(updatePath, info.Size, info.Sha256))
                throw new Exception("Новый лаунчер скачан, но SHA256/размер не совпадает с манифестом");

            var launch = MessageBox.Show(
                "Новая версия лаунчера скачана и проверена.\n\n" +
                "Запустить её сейчас? Текущий лаунчер закроется.",
                "Обновление готово",
                MessageBoxButton.YesNo,
                MessageBoxImage.Information);

            if (launch != MessageBoxResult.Yes)
            {
                SetStatus($"Лаунчер v{info.Version} скачан: {updatePath}");
                return false;
            }

            Process.Start(new ProcessStartInfo(updatePath) { UseShellExecute = true });
            Application.Current.Shutdown();
            return true;
        }
        catch (Exception ex)
        {
            SetStatus("Не удалось проверить/скачать обновление лаунчера: " + ex.Message, error: true);
            return false;
        }
    }

    private async Task EnsureModUpToDate(ClientInfo info)
    {
        if (info.Files is { Count: > 0 })
        {
            await EnsureManifestFilesUpToDate(info);
            EnsureDoomsdayClientModInfo(info.Version);
            return;
        }

        var dllPath = GameFinder.GetDoomsdayClientDllPath(_gamePath!);
        Directory.CreateDirectory(Path.GetDirectoryName(dllPath)!);

        string? currentSha = null;
        if (File.Exists(dllPath))
        {
            currentSha = ComputeSha256(dllPath);
            var ok = string.Equals(currentSha, info.Sha256, StringComparison.OrdinalIgnoreCase);
            txtSha.Text = currentSha[..16] + "... " + (ok ? "✓" : "✗");
        }
        else txtSha.Text = "(отсутствует)";

        if (!string.Equals(currentSha, info.Sha256, StringComparison.OrdinalIgnoreCase))
        {
            SetStatus($"Скачиваю DoomsdayClient.dll {FormatSize(info.Size)}...");
            await DownloadWithFallbackAndProgress(Sources.DllName, dllPath, info.Size, info.Url);
            var newSha = ComputeSha256(dllPath);
            if (!string.Equals(newSha, info.Sha256, StringComparison.OrdinalIgnoreCase))
            {
                File.Delete(dllPath);
                throw new Exception("SHA256 mismatch");
            }
            txtSha.Text = newSha[..16] + "... ✓";
        }

        EnsureDoomsdayClientModInfo(info.Version);
    }

    private void EnsureDoomsdayClientModInfo(string version)
    {
        if (_gamePath == null) return;

        var modInfoPath = GameFinder.GetDoomsdayClientModInfoPath(_gamePath);
        Directory.CreateDirectory(Path.GetDirectoryName(modInfoPath)!);

        var modInfo =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n" +
            "<xml>\r\n" +
            "\t<Name value=\"DoomsdayClient\" />\r\n" +
            "\t<DisplayName value=\"Doomsday\" />\r\n" +
            "\t<Description value=\"Doomsday Client\" />\r\n" +
            "\t<Author value=\"Doomsday Team\" />\r\n" +
            "\t<Version value=\"" + EscapeXmlAttribute(version) + "\" />\r\n" +
            "\t<Website value=\"\" />\r\n" +
            "</xml>\r\n";

        if (!File.Exists(modInfoPath) || File.ReadAllText(modInfoPath) != modInfo)
            File.WriteAllText(modInfoPath, modInfo);
    }

    private static string EscapeXmlAttribute(string value) =>
        (value ?? "0.0.0")
        .Replace("&", "&amp;")
        .Replace("\"", "&quot;")
        .Replace("<", "&lt;")
        .Replace(">", "&gt;");

    private void CleanupLegacyDoomsdayXmlMod()
    {
        // Legacy XML mod cleanup is handled only by the shared Mods cleanup prompt.
    }

    private void EnsureTfpHarmonyModInfo()
    {
        if (_gamePath == null) return;
        var harmonyDir = Path.Combine(GameFinder.GetModsPath(_gamePath), "0_TFP_Harmony");
        Directory.CreateDirectory(harmonyDir);

        const string tfpHarmonyModInfo =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n" +
            "<xml>\r\n" +
            "\t<Name value=\"TFP_Harmony\" />\r\n" +
            "\t<DisplayName value=\"Harmony Wrapper\" />\r\n" +
            "\t<Description value=\"Sets up basic HarmonyX configuration to be used with 7 Days to Die\" />\r\n" +
            "\t<Author value=\"The Fun Pimps LLC\" />\r\n" +
            "\t<Version value=\"1.1.0.4\" />\r\n" +
            "\t<Website value=\"\" />\r\n" +
            "\t<SkipWithAntiCheat value=\"true\" />\r\n" +
            "</xml>\r\n";

        var modInfoPath = Path.Combine(harmonyDir, "ModInfo.xml");
        if (!File.Exists(modInfoPath) || File.ReadAllText(modInfoPath) != tfpHarmonyModInfo)
            File.WriteAllText(modInfoPath, tfpHarmonyModInfo);
    }

    private async Task EnsureManifestFilesUpToDate(ClientInfo info)
    {
        var modsRoot = Path.GetFullPath(GameFinder.GetModsPath(_gamePath!));
        Directory.CreateDirectory(modsRoot);

        foreach (var file in info.Files!)
        {
            var destPath = ResolveManifestInstallPath(modsRoot, file.Path);
            Directory.CreateDirectory(Path.GetDirectoryName(destPath)!);

            var currentSha = File.Exists(destPath) ? ComputeSha256(destPath) : null;
            var isMainDll = string.Equals(file.Path.Replace('\\', '/'), "DoomsdayClient/DoomsdayClient.dll", StringComparison.OrdinalIgnoreCase);
            if (isMainDll)
                txtSha.Text = currentSha == null ? "(отсутствует)" : currentSha[..16] + "... " + (ShaMatches(currentSha, file.Sha256) ? "✓" : "✗");

            if (ShaMatches(currentSha, file.Sha256))
                continue;

            SetStatus($"Скачиваю {Path.GetFileName(destPath)} {FormatSize(file.Size)}...");
            await DownloadWithFallbackAndProgress(GetDownloadFileName(file), destPath, file.Size, file.Url);
            var newSha = ComputeSha256(destPath);
            if (!ShaMatches(newSha, file.Sha256))
            {
                File.Delete(destPath);
                throw new Exception($"{file.Path}: SHA256 mismatch");
            }

            if (isMainDll)
                txtSha.Text = newSha[..16] + "... ✓";
        }
    }

    private static bool ShaMatches(string? actual, string expected) =>
        !string.IsNullOrWhiteSpace(actual) &&
        !string.IsNullOrWhiteSpace(expected) &&
        string.Equals(actual, expected, StringComparison.OrdinalIgnoreCase);

    private static string ResolveManifestInstallPath(string modsRoot, string manifestPath)
    {
        if (string.IsNullOrWhiteSpace(manifestPath))
            throw new Exception("client manifest contains an empty file path");

        var normalized = manifestPath.Replace('/', Path.DirectorySeparatorChar)
                                     .Replace('\\', Path.DirectorySeparatorChar);
        if (Path.IsPathRooted(normalized))
            throw new Exception("client manifest contains a rooted file path: " + manifestPath);

        var full = Path.GetFullPath(Path.Combine(modsRoot, normalized));
        var root = modsRoot.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (!full.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            throw new Exception("client manifest path escapes Mods: " + manifestPath);

        return full;
    }

    private static string GetDownloadFileName(ClientFileInfo file)
    {
        if (Uri.TryCreate(file.Url, UriKind.Absolute, out var uri))
        {
            var name = Path.GetFileName(uri.LocalPath);
            if (!string.IsNullOrWhiteSpace(name)) return name;
        }
        return Path.GetFileName(file.Path.Replace('/', Path.DirectorySeparatorChar));
    }

    private static string GetLauncherUpdatePath(LauncherInfo info)
    {
        var updatesDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "DoomsdayLauncher",
            "updates");
        Directory.CreateDirectory(updatesDir);
        return Path.Combine(updatesDir, GetSafeLauncherFileName(info));
    }

    private static string GetSafeLauncherFileName(LauncherInfo info)
    {
        string? name = null;
        if (Uri.TryCreate(info.Url, UriKind.Absolute, out var uri))
            name = Path.GetFileName(uri.LocalPath);

        if (string.IsNullOrWhiteSpace(name) || !name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
            name = $"DoomsdayLauncher-v{SanitizeFilePart(info.Version)}.exe";

        foreach (var ch in Path.GetInvalidFileNameChars())
            name = name.Replace(ch, '_');

        if (!name.StartsWith("DoomsdayLauncher-", StringComparison.OrdinalIgnoreCase))
            name = $"DoomsdayLauncher-v{SanitizeFilePart(info.Version)}.exe";

        return name;
    }

    private static bool EnsureLauncherInstalledAndRestart()
    {
        try
        {
            var currentPath = Environment.ProcessPath;
            if (string.IsNullOrWhiteSpace(currentPath) || !File.Exists(currentPath))
                return false;

            var installedDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "DoomsdayLauncher",
                "current");
            var installedPath = Path.Combine(installedDir, "DoomsdayLauncher.exe");
            Directory.CreateDirectory(installedDir);

            if (SamePath(currentPath, installedPath))
            {
                TryCreateDesktopShortcut(installedPath);
                return false;
            }

            if (File.Exists(installedPath))
            {
                var installedVersion = GetFileVersion(installedPath);
                if (IsRemoteNewer(installedVersion, CURRENT_VERSION))
                {
                    TryCreateDesktopShortcut(installedPath);
                    Process.Start(new ProcessStartInfo(installedPath)
                    {
                        UseShellExecute = true,
                        WorkingDirectory = installedDir
                    });
                    Application.Current.Shutdown();
                    return true;
                }
            }

            var currentSha = ComputeSha256(currentPath);
            var installedSame = File.Exists(installedPath) &&
                string.Equals(ComputeSha256(installedPath), currentSha, StringComparison.OrdinalIgnoreCase);

            if (!installedSame)
            {
                var tmpPath = installedPath + ".tmp";
                if (File.Exists(tmpPath)) File.Delete(tmpPath);
                File.Copy(currentPath, tmpPath, true);
                File.Move(tmpPath, installedPath, true);
            }

            TryCreateDesktopShortcut(installedPath);
            Process.Start(new ProcessStartInfo(installedPath)
            {
                UseShellExecute = true,
                WorkingDirectory = installedDir
            });
            Application.Current.Shutdown();
            return true;
        }
        catch (Exception ex)
        {
            Debug.WriteLine("Launcher self-install skipped: " + ex.Message);
            return false;
        }
    }

    private static string GetFileVersion(string path)
    {
        try
        {
            var info = FileVersionInfo.GetVersionInfo(path);
            return info.ProductVersion ?? info.FileVersion ?? "0.0.0";
        }
        catch
        {
            return "0.0.0";
        }
    }

    private static bool SamePath(string left, string right)
    {
        try
        {
            return string.Equals(
                Path.GetFullPath(left).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
                Path.GetFullPath(right).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
                StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return false;
        }
    }

    private static void TryCreateDesktopShortcut(string targetPath)
    {
        try
        {
            var desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            if (string.IsNullOrWhiteSpace(desktop)) return;

            var shellType = Type.GetTypeFromProgID("WScript.Shell");
            if (shellType == null) return;

            var shortcutPath = Path.Combine(desktop, "Doomsday Launcher.lnk");
            dynamic shell = Activator.CreateInstance(shellType)!;
            dynamic shortcut = shell.CreateShortcut(shortcutPath);
            shortcut.TargetPath = targetPath;
            shortcut.WorkingDirectory = Path.GetDirectoryName(targetPath);
            shortcut.Description = "Doomsday Launcher";
            shortcut.IconLocation = targetPath + ",0";
            shortcut.Save();
        }
        catch
        {
        }
    }

    private static string SanitizeFilePart(string value)
    {
        var sb = new StringBuilder(value.Length);
        foreach (var ch in value)
        {
            if (char.IsLetterOrDigit(ch) || ch == '.' || ch == '-' || ch == '_')
                sb.Append(ch);
            else
                sb.Append('_');
        }
        return sb.Length > 0 ? sb.ToString() : "latest";
    }

    private async Task EnsureMenuMusicUpToDate(MenuMusicInfo info)
    {
        var dllPath  = GameFinder.GetMenuMusicReplacerDllPath(_gamePath!);
        var oggPath  = GameFinder.GetMenuMusicReplacerOggPath(_gamePath!);
        Directory.CreateDirectory(Path.GetDirectoryName(dllPath)!);
        Directory.CreateDirectory(Path.GetDirectoryName(oggPath)!);

        // 1. DLL — sha256 verify, redownload on mismatch
        string? curDllSha = File.Exists(dllPath) ? ComputeSha256(dllPath) : null;
        if (!string.Equals(curDllSha, info.DllSha256, StringComparison.OrdinalIgnoreCase))
        {
            SetStatus($"Скачиваю MenuMusicReplacer.dll {FormatSize(info.DllSize)}...");
            await DownloadWithFallbackAndProgress(Sources.MenuMusicDllName, dllPath, info.DllSize, null);
            var newSha = ComputeSha256(dllPath);
            if (!string.Equals(newSha, info.DllSha256, StringComparison.OrdinalIgnoreCase))
            {
                File.Delete(dllPath);
                throw new Exception("MenuMusicReplacer.dll SHA256 mismatch");
            }
        }

        // 2. OGG — sha256 verify, redownload on mismatch
        string? curOggSha = File.Exists(oggPath) ? ComputeSha256(oggPath) : null;
        if (!string.Equals(curOggSha, info.OggSha256, StringComparison.OrdinalIgnoreCase))
        {
            SetStatus($"Скачиваю horde_theme.ogg {FormatSize(info.OggSize)}...");
            await DownloadWithFallbackAndProgress(Sources.MenuMusicOggName, oggPath, info.OggSize, null);
            var newSha = ComputeSha256(oggPath);
            if (!string.Equals(newSha, info.OggSha256, StringComparison.OrdinalIgnoreCase))
            {
                File.Delete(oggPath);
                throw new Exception("horde_theme.ogg SHA256 mismatch");
            }
        }

        EnsureMenuMusicModInfo();
    }

    private void EnsureMenuMusicModInfo()
    {
        if (_gamePath == null) return;

        var modInfoPath = GameFinder.GetMenuMusicReplacerModInfoPath(_gamePath);
        Directory.CreateDirectory(Path.GetDirectoryName(modInfoPath)!);

        const string modInfo =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n" +
            "<xml>\r\n" +
            "\t<Name value=\"MenuMusicReplacer\"/>\r\n" +
            "\t<DisplayName value=\"Menu Music Replacer\"/>\r\n" +
            "\t<Description value=\"Client-side: replaces main menu music with custom OGG track.\"/>\r\n" +
            "\t<Author value=\"Doomsday Team\"/>\r\n" +
            "\t<Version value=\"1.2\"/>\r\n" +
            "\t<Website value=\"\"/>\r\n" +
            "</xml>\r\n";

        if (!File.Exists(modInfoPath) || File.ReadAllText(modInfoPath) != modInfo)
            File.WriteAllText(modInfoPath, modInfo);
    }

    private async Task RefreshServersAsync()
    {
        try
        {
            var json = await GetServersStatusJsonAsync();
            var servers = JsonSerializer.Deserialize<List<ServerStatus>>(json);
            Dispatcher.Invoke(() =>
            {
                panelServers.Children.Clear();
                if (servers == null || servers.Count == 0)
                {
                    panelServers.Children.Add(MakeServerLine("(нет данных)", "", false));
                    return;
                }
                foreach (var s in servers)
                {
                    var label = s.Online
                        ? $"{s.Players}/{s.MaxPlayers}"
                        : "OFFLINE";
                    panelServers.Children.Add(MakeServerLine(s.Name, label, s.Online));
                }
            });
        }
        catch
        {
            Dispatcher.Invoke(() =>
            {
                panelServers.Children.Clear();
                panelServers.Children.Add(MakeServerLine("(сервер недоступен)", "", false));
            });
        }
    }

    private async Task<string> GetServersStatusJsonAsync()
    {
        Exception? last = null;
        foreach (var url in ServersApiUrls)
        {
            try
            {
                using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(Sources.PerAttemptTimeoutSeconds));
                return await _http.GetStringAsync(url, timeout.Token);
            }
            catch (Exception ex)
            {
                last = ex;
            }
        }

        throw new Exception(last?.Message ?? "server status unavailable");
    }

    private static UIElement MakeServerLine(string name, string status, bool online)
    {
        var grid = new Grid { Margin = new Thickness(0, 2, 0, 2) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(12) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        var dot = new System.Windows.Shapes.Ellipse
        {
            Width = 8, Height = 8,
            Fill = online ? System.Windows.Media.Brushes.LimeGreen : System.Windows.Media.Brushes.IndianRed,
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetColumn(dot, 0);
        grid.Children.Add(dot);

        var nameBlock = new TextBlock
        {
            Text = name,
            Foreground = System.Windows.Media.Brushes.WhiteSmoke,
            FontSize = 11,
            Margin = new Thickness(6, 0, 6, 0),
            TextTrimming = TextTrimming.CharacterEllipsis
        };
        Grid.SetColumn(nameBlock, 1);
        Grid.SetColumnSpan(nameBlock, 2);
        grid.Children.Add(nameBlock);

        var statusBlock = new TextBlock
        {
            Text = status,
            Foreground = online ? System.Windows.Media.Brushes.LimeGreen : System.Windows.Media.Brushes.Gray,
            FontSize = 11,
            FontWeight = FontWeights.Bold
        };
        Grid.SetColumn(statusBlock, 3);
        grid.Children.Add(statusBlock);

        return grid;
    }

    /// <summary>Download a file from the canonical VPS source (no URLs in UI).</summary>
    private async Task DownloadWithFallbackAndProgress(string fileName, string destPath, long knownSize, string? primaryOverride = null)
    {
        Exception? last = null;
        int attempt = 0;
        foreach (var url in Sources.UrlsFor(fileName, primaryOverride))
        {
            attempt++;
            try
            {
                if (attempt == 1) SetStatus($"Скачиваю {fileName}...");
                else SetStatus($"Попытка {attempt} — переключаюсь на резервный источник...");
                await DownloadWithProgress(url, destPath, knownSize);
                return;
            }
            catch (OperationCanceledException)
            {
                last = new TimeoutException($"{ShortUrl(url)}: timeout");
                try { if (File.Exists(destPath + ".part")) File.Delete(destPath + ".part"); } catch { }
            }
            catch (Exception ex)
            {
                last = new Exception($"{ShortUrl(url)}: {ex.Message}", ex);
                try { if (File.Exists(destPath + ".part")) File.Delete(destPath + ".part"); } catch { }
            }
        }
        var lastMessage = last?.Message ?? "unknown error";
        throw new Exception($"Download failed: {fileName}. Last error: {lastMessage}");
    }

    private static string ShortUrl(string url)
    {
        try
        {
            var uri = new Uri(url);
            return uri.Host + (uri.AbsolutePath.Length > 40 ? "..." + uri.AbsolutePath[^40..] : uri.AbsolutePath);
        }
        catch { return url.Length > 60 ? "..." + url[^60..] : url; }
    }

    private async Task DownloadWithProgress(string url, string destPath, long knownSize)
    {
        // Connect/headers phase is bounded by PerAttemptTimeoutSeconds;
        // once bytes start flowing we let the HttpClient default timeout govern total duration.
        using var connectCts = new CancellationTokenSource(TimeSpan.FromSeconds(Sources.PerAttemptTimeoutSeconds));
        using var resp = await _http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, connectCts.Token);
        resp.EnsureSuccessStatusCode();
        var total = resp.Content.Headers.ContentLength ?? knownSize;
        if (knownSize > 0 && resp.Content.Headers.ContentLength.HasValue && resp.Content.Headers.ContentLength.Value != knownSize)
            throw new Exception($"size mismatch from {ShortUrl(url)}: got {FormatSize(resp.Content.Headers.ContentLength.Value)}, expected {FormatSize(knownSize)}");
        long read = 0;
        var tmpPath = destPath + ".part";
        await using (var stream = await resp.Content.ReadAsStreamAsync())
        await using (var fs = new FileStream(tmpPath, FileMode.Create, FileAccess.Write, FileShare.None, 81920, true))
        {
            var buffer = new byte[81920];
            int n;
            var lastUpd = DateTime.UtcNow;
            while (true)
            {
                using var idleCts = new CancellationTokenSource(TimeSpan.FromSeconds(Sources.ReadIdleTimeoutSeconds));
                try
                {
                    n = await stream.ReadAsync(buffer.AsMemory(0, buffer.Length), idleCts.Token);
                }
                catch (OperationCanceledException ex)
                {
                    throw new TimeoutException($"{ShortUrl(url)}: no download progress for {Sources.ReadIdleTimeoutSeconds}s", ex);
                }
                if (n <= 0) break;

                await fs.WriteAsync(buffer.AsMemory(0, n));
                read += n;
                if ((DateTime.UtcNow - lastUpd).TotalMilliseconds > 60)
                {
                    lastUpd = DateTime.UtcNow;
                    var pct = total > 0 ? (double)read / total * 100 : 0;
                    Dispatcher.Invoke(() =>
                    {
                        progBar.Value = pct;
                        SetStatus($"Загрузка: {FormatSize(read)} / {FormatSize(total)} ({pct:F1}%)");
                    });
                }
            }
        }
        if (knownSize > 0 && read != knownSize)
        {
            try { if (File.Exists(tmpPath)) File.Delete(tmpPath); } catch { }
            throw new Exception($"downloaded size mismatch from {ShortUrl(url)}: got {FormatSize(read)}, expected {FormatSize(knownSize)}");
        }
        if (File.Exists(destPath)) File.Delete(destPath);
        File.Move(tmpPath, destPath);
        Dispatcher.Invoke(() => progBar.Value = 100);
    }

    private static bool IsRemoteNewer(string remote, string local)
    {
        try
        {
            string Norm(string v)
            {
                var parts = v.Split('.');
                while (parts.Length < 4) parts = [.. parts, "0"];
                return string.Join('.', parts[..4]);
            }
            return new Version(Norm(remote)) > new Version(Norm(local));
        }
        catch { return false; }
    }

    private static string ComputeSha256(string path)
    {
        using var stream = File.OpenRead(path);
        using var sha = SHA256.Create();
        return Convert.ToHexString(sha.ComputeHash(stream)).ToLowerInvariant();
    }

    private static bool IsVerifiedFile(string path, long expectedSize, string expectedSha256)
    {
        if (!File.Exists(path)) return false;
        if (expectedSize > 0 && new FileInfo(path).Length != expectedSize) return false;
        if (string.IsNullOrWhiteSpace(expectedSha256)) return false;
        return string.Equals(ComputeSha256(path), expectedSha256, StringComparison.OrdinalIgnoreCase);
    }

    private static string FormatSize(long bytes)
    {
        if (bytes >= 1024 * 1024) return (bytes / 1024.0 / 1024.0).ToString("F2") + " MB";
        if (bytes >= 1024) return (bytes / 1024.0).ToString("F1") + " KB";
        return bytes + " B";
    }

    private void SetStatus(string msg, bool error = false)
    {
        Dispatcher.Invoke(() =>
        {
            txtStatus.Text = msg;
            txtStatus.Foreground = error ? System.Windows.Media.Brushes.IndianRed : System.Windows.Media.Brushes.White;
        });
    }

    private void Play_Click(object sender, RoutedEventArgs e)
    {
        if (_gamePath == null) return;
        var exe = GameFinder.GetGameExePath(_gamePath);
        if (!File.Exists(exe)) { MessageBox.Show("7DaysToDie.exe не найден в " + _gamePath); return; }

        // Warn about foreign mods that will be removed before launching.
        var plan = GameFinder.PreviewCleanup(_gamePath);
        if (plan.Folders.Count > 0 || plan.Files.Count > 0)
        {
            var msg = new StringBuilder();
            msg.AppendLine("⚠ ВНИМАНИЕ: в папке Mods обнаружены ПОСТОРОННИЕ моды/файлы.");
            msg.AppendLine("При запуске игры они БУДУТ УДАЛЕНЫ, чтобы избежать конфликтов с Doomsday.");
            msg.AppendLine();
            if (plan.Folders.Count > 0)
            {
                msg.AppendLine("Папки на удаление:");
                foreach (var f in plan.Folders) msg.AppendLine("  • " + f);
            }
            if (plan.Files.Count > 0)
            {
                msg.AppendLine();
                msg.AppendLine("Файлы на удаление:");
                foreach (var f in plan.Files) msg.AppendLine("  • " + f);
            }
            msg.AppendLine();
            msg.AppendLine("СОХРАНЯЮТСЯ: " + string.Join(", ", GameFinder.AllowedMods));
            msg.AppendLine();
            msg.AppendLine("ДА — удалить и запустить игру");
            msg.AppendLine("НЕТ — отменить запуск");

            var r = MessageBox.Show(msg.ToString(), "Посторонние моды",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r != MessageBoxResult.Yes)
            {
                SetStatus("Запуск отменён. Убери чужие моды вручную или нажми ИГРАТЬ и подтверди удаление.");
                return;
            }
            try
            {
                var removed = GameFinder.CleanMods(_gamePath);
                SetStatus($"✓ Удалено {removed.Count} чужих модов/файлов");
            }
            catch (Exception ex)
            {
                SetStatus("❌ Не удалось очистить Mods: " + ex.Message, error: true);
                return;
            }
        }

        // Physically disable EAC before launching
        if (!GameFinder.IsEacDisabled(_gamePath))
        {
            GameFinder.DisableEasyAntiCheat(_gamePath, out var msg2);
            SetStatus("EAC: " + msg2);
            UpdateEacStatus();
        }

        Process.Start(new ProcessStartInfo
        {
            FileName = exe,
            WorkingDirectory = _gamePath,
            UseShellExecute = false,
            Arguments = "-noeac -nogs -skipintro"
        });
        Application.Current.Shutdown();
    }

    private void UpdateEacStatus()
    {
        if (_gamePath == null) return;
        Dispatcher.Invoke(() =>
        {
            if (GameFinder.IsEacDisabled(_gamePath))
            {
                txtEac.Text = "✓ ОТКЛЮЧЁН";
                txtEac.Foreground = System.Windows.Media.Brushes.LimeGreen;
            }
            else
            {
                txtEac.Text = "⚠ АКТИВЕН (будет отключён при запуске)";
                txtEac.Foreground = System.Windows.Media.Brushes.Gold;
            }
        });
    }

    private void Discord_Click(object sender, RoutedEventArgs e) => OpenUrl(DISCORD_URL);

    private async void CopyElsewhere_Click(object sender, RoutedEventArgs e)
    {
        if (_gamePath == null || !File.Exists(GameFinder.GetGameExePath(_gamePath))) return;

        // Pick destination folder
        string? dest = null;
        try
        {
            var dlg = new Microsoft.Win32.OpenFolderDialog
            {
                Title = "Выбери папку (пустую — для новой копии игры, или папку с уже установленной 7 Days to Die — тогда туда просто добавится мод)",
                Multiselect = false,
                InitialDirectory = "C:\\"
            };
            if (dlg.ShowDialog(this) == true) dest = dlg.FolderName;
        }
        catch
        {
            using var wfd = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Выбери папку (пустую для новой копии, или с уже установленной игрой для установки мода)",
                UseDescriptionForTitle = true,
                ShowNewFolderButton = true
            };
            if (wfd.ShowDialog() == System.Windows.Forms.DialogResult.OK) dest = wfd.SelectedPath;
        }

        if (string.IsNullOrEmpty(dest)) return;

        // Validate destination — same folder as current
        if (string.Equals(Path.GetFullPath(dest), Path.GetFullPath(_gamePath), StringComparison.OrdinalIgnoreCase))
        {
            MessageBox.Show("Это та же папка, где игра уже установлена. Выбери другую.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        // v5.5: запретить корни дисков (C:\, D:\ etc.) — случайный выбор = перезапись всего диска
        try
        {
            var root = Path.GetPathRoot(Path.GetFullPath(dest));
            if (!string.IsNullOrEmpty(root) &&
                string.Equals(Path.GetFullPath(dest).TrimEnd('\\', '/'),
                              root.TrimEnd('\\', '/'),
                              StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show(
                    $"Нельзя выбирать корень диска ({dest}).\n\n" +
                    "Создай отдельную папку (например, D:\\Doomsday) или выбери папку где уже установлена 7 Days to Die.",
                    "Недопустимая папка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
        }
        catch { }

        // v5.4: если в dest УЖЕ установлена 7 Days to Die — не копируем,
        // просто переключаем _gamePath и ставим мод (мод весит 302 KB, не надо дублировать 74 GB игру)
        bool destHasGame = File.Exists(GameFinder.GetGameExePath(dest));
        if (destHasGame)
        {
            var r = MessageBox.Show(
                $"В этой папке УЖЕ установлена 7 Days to Die:\n{dest}\n\n" +
                "Копировать игру не нужно — я просто установлю сюда мод (302 KB, несколько секунд).\n\n" +
                "Продолжить?",
                "Игра уже установлена", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (r != MessageBoxResult.Yes) return;

            btnPlay.IsEnabled = false;
            btnCopyElsewhere.IsEnabled = false;
            try
            {
                SetStatus("Переключаюсь на эту папку + устанавливаю мод...");
                _gamePath = dest;
                _config.GamePath = dest;
                _config.Save();
                txtPath.Text = dest;
                UpdateEacStatus();
                await ProceedAsync();
            }
            catch (Exception ex)
            {
                SetStatus("❌ " + ex.Message, error: true);
                btnCopyElsewhere.IsEnabled = true;
            }
            return;
        }

        // Dest не содержит игру → планируем полное копирование.
        // Если папка не пустая — предупреждаем (скорее всего пользователь промахнулся с выбором)
        if (Directory.Exists(dest) && Directory.EnumerateFileSystemEntries(dest).Any())
        {
            var r = MessageBox.Show(
                $"Выбранная папка НЕ пустая и в ней нет установленной 7 Days to Die:\n\n{dest}\n\n" +
                "Похоже, ты выбрал не ту папку. Рекомендую ОТМЕНИТЬ и:\n" +
                "  • либо выбрать папку с уже установленной игрой (обычно Steam\\steamapps\\common\\7 Days To Die)\n" +
                "  • либо создать НОВУЮ пустую папку (например D:\\Doomsday) для копии игры\n\n" +
                "Если всё-таки продолжить — файлы игры (74 GB) будут записаны в эту папку поверх существующих файлов. Продолжить?",
                "Проверь выбор папки", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (r != MessageBoxResult.Yes) return;
        }

        // Confirm full copy
        long srcSize = 0;
        try
        {
            srcSize = new DirectoryInfo(_gamePath).EnumerateFiles("*", SearchOption.AllDirectories).Sum(f => f.Length);
        }
        catch { }

        var confirm = MessageBox.Show(
            $"Скопировать игру ЦЕЛИКОМ:\n\n" +
            $"ИЗ:  {_gamePath}\n" +
            $"В:   {dest}\n\n" +
            $"Размер: {FormatSize(srcSize)}\n\n" +
            "ВАЖНО: закрой Steam и саму игру перед копированием! Это займёт несколько минут.\n\nПродолжить?",
            "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (confirm != MessageBoxResult.Yes) return;

        btnPlay.IsEnabled = false;
        btnCopyElsewhere.IsEnabled = false;

        try
        {
            SetStatus("Копирование игры... (это займёт несколько минут)");
            var progress = new Progress<FileCopier.CopyProgress>(p =>
            {
                var pct = p.TotalBytes > 0 ? (double)p.CopiedBytes / p.TotalBytes * 100 : 0;
                progBar.Value = pct;
                SetStatus($"{FormatSize(p.CopiedBytes)} / {FormatSize(p.TotalBytes)} ({pct:F1}%)");
            });

            var skipped = await FileCopier.CopyDirectoryAsync(_gamePath, dest, progress);

            if (skipped.Count > 0)
                SetStatus($"⚠ Пропущено {skipped.Count} заблокированных файлов. Закрой Steam и попробуй снова.", error: true);
            else
                SetStatus("✓ Игра скопирована. Устанавливаю мод...");

            _gamePath = dest;
            _config.GamePath = dest;
            _config.Save();
            txtPath.Text = dest;
            UpdateEacStatus();

            await ProceedAsync();
        }
        catch (Exception ex)
        {
            SetStatus("❌ Ошибка копирования: " + ex.Message, error: true);
            btnCopyElsewhere.IsEnabled = true;
        }
    }

    private async void PickFolder_Click(object sender, RoutedEventArgs e)
    {
        string? chosen = null;
        var initial = _gamePath ?? "C:\\";

        // Try modern WPF OpenFolderDialog first (.NET 8+)
        try
        {
            var dlg = new Microsoft.Win32.OpenFolderDialog
            {
                Title = "Выбери папку игры 7 Days To Die (где лежит 7DaysToDie.exe)",
                Multiselect = false,
                InitialDirectory = initial
            };
            if (dlg.ShowDialog(this) == true)
                chosen = dlg.FolderName;
            else
                return; // user cancelled
        }
        catch
        {
            // Fallback: WinForms Vista-style picker
            using var wfd = new System.Windows.Forms.FolderBrowserDialog
            {
                Description = "Выбери папку игры 7 Days To Die (где лежит 7DaysToDie.exe)",
                UseDescriptionForTitle = true,
                InitialDirectory = initial,
                ShowNewFolderButton = true
            };
            if (wfd.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;
            chosen = wfd.SelectedPath;
        }

        if (string.IsNullOrEmpty(chosen)) return;
        _gamePath = chosen;
        _config.GamePath = chosen;
        _config.Save();
        txtPath.Text = chosen;
        UpdateEacStatus();

        if (!File.Exists(GameFinder.GetGameExePath(chosen)))
        {
            var r = MessageBox.Show(
                $"В выбранной папке нет 7DaysToDie.exe:\n\n{chosen}\n\n" +
                "Всё равно использовать эту папку? (кнопка ИГРАТЬ будет неактивна)",
                "Папка без игры", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (r != MessageBoxResult.Yes)
            {
                SetStatus("Отменено. Выбери другую папку.", error: true);
                return;
            }
            SetStatus("⚠ 7DaysToDie.exe не найден в этой папке.", error: true);
            btnPlay.IsEnabled = false;
            return;
        }

        btnPlay.IsEnabled = false;
        await ProceedAsync();
    }

    private void CleanMods_Click(object sender, RoutedEventArgs e)
    {
        if (_gamePath == null) return;

        var plan = GameFinder.PreviewCleanup(_gamePath);

        if (plan.Folders.Count == 0 && plan.Files.Count == 0)
        {
            SetStatus("✓ Папка Mods уже чистая — удалять нечего");
            return;
        }

        var items = new StringBuilder();
        items.AppendLine("Будут УДАЛЕНЫ из Mods:");
        items.AppendLine();
        if (plan.Folders.Count > 0)
        {
            items.AppendLine("Папки:");
            foreach (var f in plan.Folders) items.AppendLine("  • " + f);
        }
        if (plan.Files.Count > 0)
        {
            items.AppendLine();
            items.AppendLine("Файлы:");
            foreach (var f in plan.Files) items.AppendLine("  • " + f);
        }
        items.AppendLine();
        items.AppendLine("СОХРАНЯЮТСЯ:");
        items.AppendLine("  • " + string.Join(", ", GameFinder.AllowedMods));
        if (plan.IsDevWorkspace)
        {
            items.AppendLine();
            items.AppendLine("⚠ Обнаружена DEV-папка (.git/.vscode/...). Она защищена и НЕ будет удалена.");
        }
        items.AppendLine();
        items.AppendLine("Продолжить?");

        if (MessageBox.Show(items.ToString(), "Подтверждение очистки Mods", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;

        try
        {
            var removed = GameFinder.CleanMods(_gamePath);
            SetStatus($"✓ Удалено {removed.Count}: {string.Join(", ", removed)}");
        }
        catch (Exception ex) { SetStatus("❌ " + ex.Message, error: true); }
    }

    private async void Redownload_Click(object sender, RoutedEventArgs e)
    {
        if (_gamePath == null || _clientInfo == null) return;
        var dll = GameFinder.GetDoomsdayClientDllPath(_gamePath);
        if (File.Exists(dll)) File.Delete(dll);
        btnPlay.IsEnabled = false;
        try { await EnsureModUpToDate(_clientInfo); btnPlay.IsEnabled = true; SetStatus("✓ Готово"); }
        catch (Exception ex) { SetStatus("❌ " + ex.Message, error: true); }
    }

    private void OpenFolder_Click(object sender, RoutedEventArgs e)
    {
        if (_gamePath != null && Directory.Exists(_gamePath))
            Process.Start(new ProcessStartInfo("explorer.exe", _gamePath) { UseShellExecute = true });
    }

    private void OpenUrl(string url)
    {
        try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); } catch { }
    }
}
