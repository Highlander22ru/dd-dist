using System.IO;
using Microsoft.Win32;

namespace DoomsdayLauncher;

public static class GameFinder
{
    private static readonly string[] SkipDirNames =
    {
        "windows", "$recycle.bin", "system volume information",
        "programdata", "$windows.~bt", "$windows.~ws", "recovery",
        "perflogs", "documents and settings", "msocache",
        "onedrivetemp", "config.msi", "intel", "appdata",
        "drivers", "program files", "program files (x86)"
    };

    private static readonly string[] GameDirNames = { "7 Days To Die", "7DaysToDie", "7DTD" };

    /// <summary>Find ALL valid game installations on the system.</summary>
    public static List<string> FindAllGameInstalls()
    {
        var found = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // 1) Steam libraries (primary)
        try
        {
            using var key = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64)
                .OpenSubKey(@"SOFTWARE\WOW6432Node\Valve\Steam")
                ?? Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Valve\Steam");
            var steam = key?.GetValue("InstallPath") as string;
            if (steam != null)
            {
                AddIfValid(found, Path.Combine(steam, "steamapps", "common", "7 Days To Die"));

                var vdf = Path.Combine(steam, "steamapps", "libraryfolders.vdf");
                if (File.Exists(vdf))
                {
                    var content = File.ReadAllText(vdf);
                    foreach (System.Text.RegularExpressions.Match m in
                        System.Text.RegularExpressions.Regex.Matches(content, "\"path\"\\s*\"([^\"]+)\""))
                    {
                        var libPath = m.Groups[1].Value.Replace("\\\\", "\\");
                        AddIfValid(found, Path.Combine(libPath, "steamapps", "common", "7 Days To Die"));
                    }
                }
            }
        }
        catch { }

        // 2) Well-known root patterns on each fixed drive
        foreach (var drive in DriveInfo.GetDrives())
        {
            if (drive.DriveType != DriveType.Fixed) continue;
            var root = drive.RootDirectory.FullName;
            foreach (var n in GameDirNames)
            {
                AddIfValid(found, Path.Combine(root, n));
                AddIfValid(found, Path.Combine(root, n, n));
                AddIfValid(found, Path.Combine(root, "Games", n));
                AddIfValid(found, Path.Combine(root, "Games", n, n));
                AddIfValid(found, Path.Combine(root, "SteamLibrary", "steamapps", "common", n));
            }
        }

        return found.ToList();
    }

    private static void AddIfValid(HashSet<string> set, string path)
    {
        try
        {
            // Reject if path contains any skip-dir name (e.g. $RECYCLE.BIN)
            foreach (var seg in path.Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar))
            {
                if (SkipDirNames.Contains(seg.ToLowerInvariant())) return;
            }
            if (File.Exists(Path.Combine(path, "7DaysToDie.exe")))
                set.Add(Path.GetFullPath(path));
        }
        catch { }
    }

    public static string? FindGamePath() => FindAllGameInstalls().FirstOrDefault();

    public static string GetModsPath(string gamePath) =>
        Path.Combine(gamePath, "Mods");

    public static string GetDoomsdayClientDllPath(string gamePath) =>
        Path.Combine(gamePath, "Mods", "DoomsdayClient", "DoomsdayClient.dll");

    public static string GetDoomsdayClientModInfoPath(string gamePath) =>
        Path.Combine(gamePath, "Mods", "DoomsdayClient", "ModInfo.xml");

    public static string GetMenuMusicReplacerDirPath(string gamePath) =>
        Path.Combine(gamePath, "Mods", "MenuMusicReplacer");

    public static string GetGameExePath(string gamePath) =>
        Path.Combine(gamePath, "7DaysToDie.exe");

    public static readonly HashSet<string> AllowedMods = new(StringComparer.OrdinalIgnoreCase)
    {
        "0_TFP_Harmony",
        "DoomsdayClient",
        "DoomsdayOptimizer",
        "DoomsdayServer",
        "BossLootProtection",
    };

    // Dev-environment markers — if any of these exist in Mods/, refuse automatic cleanup
    public static readonly HashSet<string> DevMarkers = new(StringComparer.OrdinalIgnoreCase)
    {
        ".git", ".github", ".vscode", ".venv", ".idea", ".claude", ".playwright-mcp",
        "node_modules", "obj", "bin"
    };

    public record CleanPlan(List<string> Folders, List<string> Files, bool IsDevWorkspace);

    public static CleanPlan PreviewCleanup(string gamePath)
    {
        var folders = new List<string>();
        var files = new List<string>();
        bool dev = false;
        var modsPath = GetModsPath(gamePath);
        if (!Directory.Exists(modsPath)) return new CleanPlan(folders, files, false);

        foreach (var sub in Directory.GetDirectories(modsPath))
        {
            var name = Path.GetFileName(sub);
            if (AllowedMods.Contains(name)) continue;
            if (DevMarkers.Contains(name)) { dev = true; continue; }
            folders.Add(name);
        }
        // Any dev marker anywhere in Mods root?
        foreach (var sub in Directory.GetDirectories(modsPath))
            if (DevMarkers.Contains(Path.GetFileName(sub))) dev = true;

        foreach (var file in Directory.GetFiles(modsPath))
            files.Add(Path.GetFileName(file));

        return new CleanPlan(folders, files, dev);
    }

    public static bool RemoveLegacyDoomsdayXmlMod(string gamePath, out string? message)
    {
        message = null;
        var legacyDir = Path.Combine(GetModsPath(gamePath), "Doomsday");
        if (!Directory.Exists(legacyDir)) return false;

        if (ContainsDevMarker(legacyDir))
        {
            message = "Найдена папка Mods\\Doomsday, но она похожа на DEV-папку; автоудаление пропущено";
            return false;
        }

        Directory.Delete(legacyDir, recursive: true);
        message = "Старый XML-мод Mods\\Doomsday удалён: XML должен подгружаться сервером";
        return true;
    }

    private static bool ContainsDevMarker(string dir)
    {
        try
        {
            foreach (var entry in Directory.EnumerateFileSystemEntries(dir, "*", SearchOption.AllDirectories))
            {
                if (DevMarkers.Contains(Path.GetFileName(entry))) return true;
            }
        }
        catch { }
        return false;
    }

    /// <summary>
    /// Rename EasyAntiCheat folder so the game cannot load EAC launcher.
    /// Returns true if EAC was physically disabled now (or already disabled).
    /// </summary>
    public static bool DisableEasyAntiCheat(string gamePath, out string message)
    {
        var eacActive = Path.Combine(gamePath, "EasyAntiCheat");
        var eacDisabled = Path.Combine(gamePath, "EasyAntiCheat_disabled");

        if (Directory.Exists(eacDisabled) && !Directory.Exists(eacActive))
        {
            message = "EAC уже отключён (папка переименована в EasyAntiCheat_disabled)";
            return true;
        }

        if (!Directory.Exists(eacActive))
        {
            message = "Папка EasyAntiCheat не найдена — возможно, игра уже без EAC";
            return true;
        }

        try
        {
            if (Directory.Exists(eacDisabled))
            {
                // Merge: delete old disabled and rename active
                Directory.Delete(eacDisabled, recursive: true);
            }
            Directory.Move(eacActive, eacDisabled);
            message = "EAC отключён (папка переименована в EasyAntiCheat_disabled)";
            return true;
        }
        catch (Exception ex)
        {
            message = "Не удалось переименовать папку EAC: " + ex.Message;
            return false;
        }
    }

    public static bool IsEacDisabled(string gamePath)
    {
        return !Directory.Exists(Path.Combine(gamePath, "EasyAntiCheat"))
            || Directory.Exists(Path.Combine(gamePath, "EasyAntiCheat_disabled"));
    }

    public static List<string> CleanMods(string gamePath)
    {
        var removed = new List<string>();
        var modsPath = GetModsPath(gamePath);
        if (!Directory.Exists(modsPath)) return removed;

        foreach (var sub in Directory.GetDirectories(modsPath))
        {
            var name = Path.GetFileName(sub);
            if (AllowedMods.Contains(name)) continue;
            if (DevMarkers.Contains(name)) continue; // Protect dev folders
            try { Directory.Delete(sub, true); removed.Add(name); } catch { }
        }
        foreach (var file in Directory.GetFiles(modsPath))
        {
            try { File.Delete(file); removed.Add("(file) " + Path.GetFileName(file)); } catch { }
        }
        return removed;
    }
}
