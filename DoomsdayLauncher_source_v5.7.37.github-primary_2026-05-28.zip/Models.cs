using System.Text.Json.Serialization;

namespace DoomsdayLauncher;

public record LauncherInfo(
    [property: JsonPropertyName("version")] string Version,
    [property: JsonPropertyName("url")] string Url,
    [property: JsonPropertyName("sha256")] string Sha256,
    [property: JsonPropertyName("size")] long Size,
    [property: JsonPropertyName("changelog")] string? Changelog,
    [property: JsonPropertyName("released")] string? Released
);

public record ClientInfo(
    [property: JsonPropertyName("version")] string Version,
    [property: JsonPropertyName("url")] string Url,
    [property: JsonPropertyName("sha256")] string Sha256,
    [property: JsonPropertyName("size")] long Size,
    [property: JsonPropertyName("notes")] string? Notes,
    [property: JsonPropertyName("files")] List<ClientFileInfo>? Files
);

public record ClientFileInfo(
    [property: JsonPropertyName("path")] string Path,
    [property: JsonPropertyName("url")] string Url,
    [property: JsonPropertyName("sha256")] string Sha256,
    [property: JsonPropertyName("size")] long Size
);

public record ServerStatus(
    [property: JsonPropertyName("id")] int Id,
    [property: JsonPropertyName("name")] string Name,
    [property: JsonPropertyName("online")] bool Online,
    [property: JsonPropertyName("players")] int Players,
    [property: JsonPropertyName("maxPlayers")] int MaxPlayers
);
