using System.Net.Http;

namespace DoomsdayLauncher;

/// <summary>Multi-source downloader with automatic fallback and per-attempt connect timeout.</summary>
public static class Sources
{
    // Preferred order of mirrors (first = primary, rest = fallbacks)
    // v5.3 (2026-04-24): GitHub PRIMARY — у РФ-игроков оказалось что .online через CF
    // тормозит (перегрузка CF Moscow edge, плохой пиринг, CF cache bypass был раньше).
    // GitHub releases (Fastly CDN) работает у всех ISP в РФ без блокировок РКН. Это надёжнее.
    // .online fallback — если у игрока с GitHub почему-то проблема.
    public static readonly string[] Mirrors = new[]
    {
        "https://github.com/Highlander22ru/dd-dist/releases/latest/download",       // primary (Fastly, никогда не режется в РФ)
        "https://doomsday7dtd.online/dl",                                           // fallback (CF Proxy, иногда тормозит edge)
        "https://doomsday7dtd.ru/dl",                                               // last resort (РКН ТСПУ режет >25KB по SNI)
    };

    /// <summary>Max wait per mirror before trying the next one (seconds).
    /// v5.1: 3 → 15 сек. 3 секунд не хватало на TLS handshake через CloudFlare в плохих
    /// каналах (РФ/Беларусь): соединение устанавливалось дольше → CancellationToken отменял
    /// до получения первого байта → переход на следующий mirror → каскадные таймауты.</summary>
    public const int PerAttemptTimeoutSeconds = 15;

    public const string LauncherJsonName = "launcher.json";
    public const string ClientJsonName = "client.json";
    public const string ModInfoName = "ModInfo.xml";
    public const string DllName = "DoomsdayClient.dll";
    public const string LauncherExeName = "DoomsdayLauncher.exe";

    /// <summary>Expand a file name into full URLs per mirror, with a primary override first (e.g. from JSON).</summary>
    public static IEnumerable<string> UrlsFor(string fileName, string? primaryOverride = null)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (!string.IsNullOrEmpty(primaryOverride))
        {
            yield return primaryOverride;
            seen.Add(primaryOverride);
        }
        foreach (var m in Mirrors)
        {
            var url = m.TrimEnd('/') + "/" + fileName;
            if (seen.Add(url)) yield return url;
        }
    }

    /// <summary>GET with fallback between mirrors. Reports each attempt via onAttempt.
    /// Each mirror gets <see cref="PerAttemptTimeoutSeconds"/> to start responding; otherwise next mirror is tried.</summary>
    public static async Task<HttpResponseMessage> GetWithFallbackAsync(
        HttpClient http,
        string fileName,
        string? primaryOverride = null,
        Action<string, string>? onAttempt = null,
        CancellationToken ct = default)
    {
        Exception? last = null;
        foreach (var url in UrlsFor(fileName, primaryOverride))
        {
            onAttempt?.Invoke(url, "пробую...");
            using var perAttempt = CancellationTokenSource.CreateLinkedTokenSource(ct);
            perAttempt.CancelAfter(TimeSpan.FromSeconds(PerAttemptTimeoutSeconds));
            try
            {
                var resp = await http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, perAttempt.Token);
                if (resp.IsSuccessStatusCode)
                {
                    onAttempt?.Invoke(url, "OK");
                    return resp;
                }
                last = new HttpRequestException($"{url}: HTTP {(int)resp.StatusCode}");
                onAttempt?.Invoke(url, $"HTTP {(int)resp.StatusCode}");
                resp.Dispose();
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                last = new TimeoutException($"{url}: нет ответа за {PerAttemptTimeoutSeconds}с");
                onAttempt?.Invoke(url, $"таймаут {PerAttemptTimeoutSeconds}с");
            }
            catch (Exception ex)
            {
                last = ex;
                onAttempt?.Invoke(url, "ошибка: " + ShortError(ex.Message));
            }
        }
        throw new Exception("Все источники недоступны. Последняя ошибка: " + (last?.Message ?? "неизвестно"));
    }

    /// <summary>Convenience: download full text (JSON/XML).</summary>
    public static async Task<string> GetStringWithFallbackAsync(
        HttpClient http, string fileName, string? primaryOverride = null,
        Action<string, string>? onAttempt = null, CancellationToken ct = default)
    {
        using var resp = await GetWithFallbackAsync(http, fileName, primaryOverride, onAttempt, ct);
        return await resp.Content.ReadAsStringAsync(ct);
    }

    private static string ShortError(string msg) =>
        msg.Length > 80 ? msg[..80] + "..." : msg;
}
