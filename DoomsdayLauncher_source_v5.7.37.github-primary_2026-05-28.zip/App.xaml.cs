using System.Windows;

namespace DoomsdayLauncher;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        AppDomain.CurrentDomain.UnhandledException += (s, ev) =>
        {
            var ex = ev.ExceptionObject as System.Exception;
            MessageBox.Show(
                $"Непредвиденная ошибка:\n\n{ex?.Message}\n\n{ex?.StackTrace}",
                "Doomsday Launcher",
                MessageBoxButton.OK, MessageBoxImage.Error);
        };

        DispatcherUnhandledException += (s, ev) =>
        {
            MessageBox.Show(
                $"Ошибка UI:\n\n{ev.Exception.Message}",
                "Doomsday Launcher",
                MessageBoxButton.OK, MessageBoxImage.Error);
            ev.Handled = true;
        };
    }
}
