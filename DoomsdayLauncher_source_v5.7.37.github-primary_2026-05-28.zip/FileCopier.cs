using System.IO;

namespace DoomsdayLauncher;

public static class FileCopier
{
    public record CopyProgress(string CurrentFile, long CopiedBytes, long TotalBytes, int FileIndex, int TotalFiles);

    /// <summary>Recursively copy entire directory, reporting progress. Skips locked files.</summary>
    public static async Task<List<string>> CopyDirectoryAsync(
        string sourceDir,
        string destDir,
        IProgress<CopyProgress>? progress,
        CancellationToken ct = default)
    {
        var skipped = new List<string>();

        if (!Directory.Exists(sourceDir))
            throw new DirectoryNotFoundException($"Папка источника не найдена: {sourceDir}");

        Directory.CreateDirectory(destDir);

        // 1. Collect file list + total size
        var files = Directory.EnumerateFiles(sourceDir, "*", SearchOption.AllDirectories).ToArray();
        long totalSize = 0;
        foreach (var f in files)
        {
            try { totalSize += new FileInfo(f).Length; } catch { }
        }

        long copied = 0;
        int idx = 0;

        foreach (var file in files)
        {
            ct.ThrowIfCancellationRequested();
            idx++;
            var rel = Path.GetRelativePath(sourceDir, file);
            var destFile = Path.Combine(destDir, rel);
            Directory.CreateDirectory(Path.GetDirectoryName(destFile)!);

            long fileSize = 0;
            try { fileSize = new FileInfo(file).Length; } catch { }

            try
            {
                await using var src = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite, 81920, true);
                await using var dst = new FileStream(destFile, FileMode.Create, FileAccess.Write, FileShare.None, 81920, true);
                var buf = new byte[81920];
                int n;
                while ((n = await src.ReadAsync(buf, ct)) > 0)
                {
                    await dst.WriteAsync(buf.AsMemory(0, n), ct);
                    copied += n;
                    progress?.Report(new CopyProgress(rel, copied, totalSize, idx, files.Length));
                }
            }
            catch (IOException)
            {
                skipped.Add(rel);
                // Advance progress so bar keeps moving
                copied += fileSize;
                progress?.Report(new CopyProgress($"(пропущено) {rel}", copied, totalSize, idx, files.Length));
            }
        }

        return skipped;
    }
}
